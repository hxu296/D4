hazy: Hazy images. Scaled to 620x460 using ffmpeg to be compatible with the pretrained model.

results: Dehazed images. Output by D4.

pretrained model: https://drive.google.com/file/d/1KLvPdNpskdVDSz0qEIP_tn-j2MwTcJAV/view

